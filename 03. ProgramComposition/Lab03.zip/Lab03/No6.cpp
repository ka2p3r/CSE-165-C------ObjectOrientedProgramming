#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main()
{
    vector<string> words;
    string input;
    while (cin >> input && input != "quit")
    {
        int len = input.length();
        if (len >= 4)
        {
            words.push_back(input);
        }
        else
        {
            for (const string& word : words)
            {
                if (word.find(input) == 0)
                {
                    cout << word << endl;
                }
            }
        }
    }
    return 0;
}
