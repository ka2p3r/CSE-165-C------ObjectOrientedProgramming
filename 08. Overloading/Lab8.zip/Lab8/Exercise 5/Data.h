#ifndef DATA_H
#define DATA_H

#include <vector>
#include <iostream>
#include "Sortable.h"

using namespace std;

class Data {

public:
    vector<Sortable*> dataSet;

    void add(Sortable* sortable) {
        dataSet.push_back(sortable);
    }

    void sort() {
        bool swapped;
        int n = dataSet.size();
        
        do {
            swapped = false;
            for (int j = 0; j < n - 1; j++) {
                if (dataSet[j]->compare(dataSet[j + 1])) {
                    swap(dataSet[j], dataSet[j + 1]);
                    swapped = true;
                }
            }
            n--; 
        } while (swapped);
    }

    void print() {
        for (int i = 0; i < dataSet.size(); i++) {
            dataSet[i]->print();
            if (i < dataSet.size() - 1) {
                cout << endl;
            }
        }
        cout << endl << endl;
    }
};

#endif
