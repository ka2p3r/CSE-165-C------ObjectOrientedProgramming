#ifndef DATA_H
#define DATA_H

#include <vector>
#include <iostream>

using namespace std;

class Data {
public:
    vector<int> dataSet;

    void add(int number) {
        dataSet.push_back(number);
    }

    void sort() {
        bool swapped;
        int n = dataSet.size();

        do {
            swapped = false;
            for (int j = 0; j < n - 1; j++) {
                if (dataSet[j] > dataSet[j + 1]) {
                    swap(dataSet[j], dataSet[j + 1]);
                    swapped = true;
                }
            }
            n--;
        } while (swapped);
    }

    void print() {
        for (int i = 0; i < dataSet.size(); i++) {
            cout << dataSet[i] << " ";
        }
        cout << endl;
    }
};

#endif
