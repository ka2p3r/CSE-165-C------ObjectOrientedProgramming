#ifndef STACK_H
#define STACK_H

#include <iostream>
#include <vector>

namespace std {

    class Stack {

    protected:
        vector<double> elements;

    public:
        Stack() = default;

        Stack(int n) {
            elements.reserve(n);
            for (int i = 0; i < n; i++) {
                elements.push_back(1.0 + (i * 0.1));
            }
        }

        ~Stack() {
            for (auto it = elements.rbegin(); it != elements.rend(); ++it) {
                std::cout << *it << " ";
            }
        }

        void push(double value) {
            elements.push_back(value);
        }

        void pop() {
            if (elements.empty()) {
                std::cout << "Stack is empty" << std::endl;
                return;
            }
            elements.pop_back();
        }
    };
}

#endif

