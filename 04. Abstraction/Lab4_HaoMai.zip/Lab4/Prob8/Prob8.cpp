#include <iostream>
#include "Stash.h"

int main() {
    Stash s;
    int increment;
    std::cin >> increment;
    s.initialize(1, increment);
  
    char c;
    int n;
    while (true) {
        std::cin >> c >> n;
        if (c == '&' && n == 99)
            break;

        if (n >= 0) {
            for (int i = 0; i < n; i++) {
                s.add(&c);
            }
        }
        else {
            int abs_n = -n;
            for (int i = 0; i < abs_n; i++) {
                s.add(&c);
            }
            char newline = '\n';
            s.add(&newline);
        }
    }

    for (int i = 0; i < s.count(); i++) {
        std::cout << *(char*)s.fetch(i);
    }

    std::cout << std::endl << s.realloc_count << " " << s.quantity << std::endl;
    s.cleanup();
    return 0;
}
