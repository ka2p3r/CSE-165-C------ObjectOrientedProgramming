#ifndef ENTRY_H
#define ENTRY_H

#include <iostream>
#include <string>
using namespace std;

struct Entry {
    string name;
    string lastname;
    string email;

    string getName() const {
        return name;
    }

    string getLastname() const {
        return lastname;
    }

    string getEmail() const {
        return email;
    }

    void setName(const string& n) {
        name = n;
    }

    void setLastname(const string& ln) {
        lastname = ln;
    }

    void setEmail(const string& e) {
        email = e;
    }

    void print() const {
        cout << name << "," << lastname << "," << email << endl;
    }
};

#endif


