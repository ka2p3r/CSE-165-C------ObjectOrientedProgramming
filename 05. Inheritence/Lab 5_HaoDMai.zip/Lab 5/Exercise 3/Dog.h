#ifndef DOG_H
#define DOG_H

#include <string>
#include "Animal.h"
#include <iostream>

namespace std {

    class Dog : public Animal {
    public:
        Dog() {
            cout << "Creating Dog" << endl;
        }

        Dog(string name, int age) {
            cout << "Creating Dog" << endl;
            setName(name);
            setAge(age);
        }

        void feed() {
            cout << "Dog food, please!" << endl;
        }
    };

}

#endif
