#include <iostream>
#include <vector>
#include "Animal.h"
#include "Dog.h"
#include "display.h"

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<Animal*> anmls;

    for (int i = 0; i < n; i++) {
        char type;
        string name;
        int age;
        cin >> type >> name >> age;

        Animal* animal = (type == 'A') ? new Animal() : new Dog(name, age);
        animal->setName(name);
        animal->setAge(age);
        anmls.push_back(animal);
    }

    display(anmls);


    for (int i = 0; i < anmls.size(); i++) {
        delete anmls[i];
    }

    return 0;
}

