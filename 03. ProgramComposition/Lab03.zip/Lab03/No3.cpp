#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<int> values;
    int input, sum = 0;
    while (cin >> input && input != 0)
    {
        if (input > 0)
        {
            values.push_back(input);
            sum += input;
        }
        else
        {
            for (int i = 0; i < values.size(); i++)
            {
                if (values[i] == abs(input))
                {
                    sum -= values[i];
                    values.erase(values.begin() + i);
                    break;
                }
            }
        }
    }
    cout << values.size() << " " << sum << endl;

    return 0;
}