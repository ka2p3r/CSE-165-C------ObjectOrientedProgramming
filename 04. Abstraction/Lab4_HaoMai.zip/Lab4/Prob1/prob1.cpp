#include "Stash.h"
#include <iostream>

int main() {
    Stash doubleStash;
    doubleStash.initialize(sizeof(double));
    int n;
    std::cin >> n;

    for (int i = 0; i < n; i++) {
        double num;
        std::cin >> num;
        doubleStash.add(&num);
    }

    for (int i = 0; i < doubleStash.count(); i++) {
        double& num = *(static_cast<double*>(doubleStash.fetch(i)));
        std::cout << " " << num << "\n";
    }

    doubleStash.cleanup();
    return 0;
}

