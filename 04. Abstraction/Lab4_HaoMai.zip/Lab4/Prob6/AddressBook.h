#ifndef ADDRESSBOOK_H
#define ADDRESSBOOK_H

#include "Entry.h"
#include <vector>

struct AddressBook {
    std::vector<Entry> entries;

    void addEntry(const Entry& entry) {
        entries.push_back(entry);
    }

    void printEntries() const {
        for (const Entry& entry : entries) {
            entry.print();
        }
    }
};

#endif
