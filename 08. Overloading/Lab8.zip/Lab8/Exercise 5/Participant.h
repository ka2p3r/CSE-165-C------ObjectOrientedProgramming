#ifndef PARTICIPANT_H
#define PARTICIPANT_H

#include <iostream>
#include <string>
#include "Sortable.h"

class Participant : public Sortable {
public:
    std::string name;
    int age;
    int score;

    Participant(const std::string& n, int a, int s) : name(n), age(a), score(s) {}

    virtual bool compare(const Sortable* other) {
        const Participant* otherParticipant = dynamic_cast<const Participant*>(other);
        if (otherParticipant && comp_cb) {
            return comp_cb(this, otherParticipant);
        }
        return false;
    }

    virtual void print() {
        std::cout << name << "\t" << age << "\t" << score;
    }

    static bool (*comp_cb)(const Participant*, const Participant*);
};

#endif


