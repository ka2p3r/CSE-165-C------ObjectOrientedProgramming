#ifndef PARTICIPANT_H
#define PARTICIPANT_H

#include <string>
#include "Sortable.h"

using namespace std;

class Participant : public Sortable {
public:
    string name;
    int age;
    double score;

    Participant(const string& name, int age, double score) : name(name), age(age), score(score) {}

    bool compare(const Sortable* other) override {
        const Participant* otherParticipant = dynamic_cast<const Participant*>(other);
        if (score > otherParticipant->score) {
            return false;
        } else if (score < otherParticipant->score) {
            return true;
        } else {
            if (age < otherParticipant->age) {
                return false;
            } else if (age > otherParticipant->age) {
                return true;
            } else {
                return name > otherParticipant->name;
            }
        }
    }

    void print() override {
        cout << name << "\t" << age << "\t" << score;
    }
};

#endif 
