#include <iostream>
#include "Stack.h"

using namespace std;

int main() {
  Stack stack;
  stack.initialize();

  int n;
  cin >> n;

  for (int i = 0; i < n; i++) {
    double value;
    cin >> value;
    stack.push(new double(value));
  }

  cout << endl;
  void* value;
  while (value = stack.pop()) {
    cout << *((double*) value) << "\n";
    delete (double*) value;
  }

  stack.cleanup();

  return 0;
}






