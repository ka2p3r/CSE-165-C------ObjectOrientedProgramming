#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
  vector<string> words;
  string word;

  while (cin >> word && word != "quit") {
    if (word.size() >= 4) {
      words.push_back(word);
    } else {
      cout << "Output: ";
      for (const auto& w : words) {
        if (w.find(word) == 0) {
          cout << w << " ";
        }
      }
    }
  }

  return 0;
}