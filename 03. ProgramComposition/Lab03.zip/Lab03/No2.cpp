#include <iostream>
using namespace std;

int main()
{
    char c;
    int n;
    while (cin >> c >> n && n != -2)
    {
        if (n == -1) cout << endl;
        else cout << string(n, c) << endl;
    }
    return 0;
}
