#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main()
{
    vector<vector<string> *> V(10);
    for (int i = 0; i < 10; i++)
    {
        V[i] = new vector<string>();
    }
    string str;
    while (true)
    {
        cout << "Enter the input: ";
        cin >> str;
        if (str == "quit")
            break;
        int n = str.length();
        for (int i = 0; i < V[n - 1]->size(); i++)
        {
            if (V[n - 1]->at(i) == str)
            {
                break;
            }
            if (i == V[n - 1]->size() - 1)
            {
                V[n - 1]->push_back(str);
            }
        }
        if (V[n - 1]->size() == 0)
        {
            V[n - 1]->push_back(str);
        }
    }
    for (int i = 0; i < 10; i++)
    {
        if (V[i]->size() > 0)
        {
            for (int j = 0; j < V[i]->size(); j++)
            {
                cout << V[i]->at(j) << " ";
            }
            cout << endl;
        }
    }

    return 0;
}
