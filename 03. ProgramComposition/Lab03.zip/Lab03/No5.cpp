#include <iostream>
#include <vector>
#include <string>

using namespace std;

int main()
{
    vector<vector<string>> V(10);
    string str;
    while (true)
    {
        cout << "Enter the input: ";
        cin >> str;
        if (str == "quit")
            break;
        int n = str.length() - 1;
        bool found = false;
        for (int i = 0; i < V[n].size(); i++)
        {
            if (V[n][i] == str)
            {
                found = true;
                break;
            }
        }
        if (!found)
        {
            V[n].push_back(str);
        }
    }
    for (int i = 0; i < 10; i++)
    {
        if (V[i].size() > 0)
        {
            int len = V[i].size();
            int sum = 0;
            for (int j = 0; j < V[i].size(); j++)
            {
                sum += V[i][j].size();
            }
            cout << sum << " " << len << endl;
        }
    }

    return 0;
}
