#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <iostream>

class LinkedList {
public:
    struct Link {
        int data;
        Link* next;
        Link(int d, Link* n = NULL) : data(d), next(n) {}
    };

    Link* head;

    LinkedList(double* d, Link* n) {
        head = new Link(static_cast<int>(*d), n);
    }

    void add(Link* l, int n) {
        Link* prev = l;
        Link* curr = l->next;
        int i = 0;
        while (i < n) {
            Link* newLink = new Link(i, curr);
            prev->next = newLink;
            prev = newLink;
            curr = prev->next;
            i++;
        }
        prev->next = NULL;
    }

    void print() {
        Link* curr = head;
        while (curr != NULL) {
            std::cout << curr->data << std::endl;
            curr = curr->next;
        }
    }

    void cleanup() {
        Link* curr = head;
        while (curr != NULL) {
            Link* temp = curr;
            curr = curr->next;
            delete temp;
        }
    }
};

#endif
