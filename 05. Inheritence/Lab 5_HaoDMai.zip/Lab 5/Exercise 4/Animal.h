#ifndef ANIMAL_H
#define ANIMAL_H

#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Animal {

public:

    Animal() {
        cout << "Creating Generic Animal" << endl;
        name = "Generic Animal";
        age = 0;
        count++;
    }

    ~Animal() {
        cout << "Deleting Generic Animal" << endl;
        count--;
    }


    static int count;

    string getName() {
        return name;
    }
    
    void setAge(int age) {
        this->age = age;
    }

    void feed() {
        cout << "Some food, please!" << endl;
    }


    void setName(string name) {
        this->name = name;
    }

    int getAge() {
        return age;
    }

private:
    string name;
    int age;
};

#endif
