#ifndef CIRCLE_H
#define CIRCLE_H

#include <cmath>

class Circle {

public:

    Circle() : x(0), y(0), r(1) {
        calculateArea();
    }

    Circle(double x, double y, double r) : x(x), y(y), r(r) {
        calculateArea();
    }

    double getX() const {
        return x;
    }

    double getY() const {
        return y;
    }

    double getR() const {
        return r;
    }

    void setX(double x) {
        this->x = x;
        calculateArea();
    }

    void setY(double y) {
        this->y = y;
        calculateArea();
    }

    void setR(double r) {
        this->r = r;
        calculateArea();
    }

    double area;

private:
    double x;
    double y;
    double r;

    void calculateArea() {
        area = M_PI * r * r;
    }
};

#endif
