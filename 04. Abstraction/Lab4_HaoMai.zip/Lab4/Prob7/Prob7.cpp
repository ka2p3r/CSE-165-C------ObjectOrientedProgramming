#include <iostream>
using namespace std;

// containing 1 char and 1 double
struct struct1 {
    char c;
    double d;
};

// 2 chars and 1 double
struct struct2 {
    char c1;
    char c2;
    double d;
};

// 3 chars and 1 double
struct struct3 {
    char c1;
    char c2;
    char c3;
    double d;
};

// 4 chars and 1 double
struct struct4 {
    char c1;
    char c2;
    char c3;
    char c4;
    double d;
};

// an empty struct
struct emptyStruct {};

// 1 char, followed by 1 int and then 1 char
struct struct5 {
    char c1;
    int i;
    char c2;
};

// 2 chars followed by 1 int
struct struct6 {
    char c1;
    char c2;
    int i;
};

int main() {
    cout << "Size of struct1: " << sizeof(struct1) << endl;
    cout << "Size of struct2: " << sizeof(struct2) << endl;
    cout << "Size of struct3: " << sizeof(struct3) << endl;
    cout << "Size of struct4: " << sizeof(struct4) << endl;
    cout << "Size of emptyStruct: " << sizeof(emptyStruct) << endl;
    cout << "Size of struct5: " << sizeof(struct5) << endl;
    cout << "Size of struct6: " << sizeof(struct6) << endl;
    return 0;
}

