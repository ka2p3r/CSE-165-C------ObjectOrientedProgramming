#include <iostream>
#include "Entry.h"
#include "AddressBook.h"

using namespace std;

int main(int argc, const char * argv[])
{
    int numEntries;
    cin >> numEntries;

    AddressBook addressBook;

    for (int i = 0; i < numEntries; i++) {
        string name, lastname, email;
        cin >> name >> lastname >> email;

        Entry myEntry;
        myEntry.setName(name);
        myEntry.setLastname(lastname);
        myEntry.setEmail(email);

        addressBook.addEntry(myEntry);
    }

    addressBook.printEntries();

    return 0;
}


