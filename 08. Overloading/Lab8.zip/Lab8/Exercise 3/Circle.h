#ifndef CIRCLE_H
#define CIRCLE_H

#include <iostream>
#include "Sortable.h"

using namespace std;

class Circle : public Sortable {
private:
    float radius;

public:
    Circle(float radius = 0.0) : radius(radius) {}

    bool compare(const Sortable* other) override {
        const Circle* otherCircle = dynamic_cast<const Circle*>(other);
        if (otherCircle == nullptr) {
            return false;
        }
        return this->radius < otherCircle->radius;
    }

    void print() override {
        cout << "Circle with radius: " << radius;
    }
};

#endif

